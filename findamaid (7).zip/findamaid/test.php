<signup class="php"></signup>
<login class="php"></login>
<db class="php"></db>
<post_request class="php"></post_request>
<list_posts class="php"></list_posts>
<get_post_by_id class="php"></get_post_by_id>
<search_posts class="php"></search_posts>
<get_profile class="php"></get_profile>
<submit_address class="php"></submit_address>
<get_maid_notifications class="php"></get_maid_notifications>
<update_booking_status class="php"></update_booking_status>
<get_user_bookings class="php"></get_user_bookings>has a normal user
Shows a normal user all their bookings, statuses, and the maid's info.
<submit_review class="php"></submit_review>
<get_reviews class="php"></get_reviews>
